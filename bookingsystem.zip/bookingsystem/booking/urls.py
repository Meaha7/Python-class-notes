from django.urls import path

from . import views


urlpatterns=[
    path('',views.home, name='home'),
    path('booking/enterpost',views.enter_post, name='enterpost'),
     path('archive',views.archive, name='archive'),
   ]
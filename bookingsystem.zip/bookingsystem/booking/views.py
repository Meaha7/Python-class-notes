from django.shortcuts import render
from booking.models import Enter
from django.http import HttpResponse


# Create your views here.


def home(request):
    return render(request,"base.html")

def enter_post(request):
    s=""
    if request.method=='POST':
        try:
            fn=(request.POST.get('hotels'))
            ln=(request.POST.get('facilities'))
            ag=(request.POST.get('age'))
            n=(request.POST.get('name'))
            
            Enter(fname=fn,lname=ln,age=str(ag),name=str(n)).save()
            s= " data entered successfully"
            return render(request,'base.html',{'posts': [s]},)
        except ValueError:
            s="please enter text properly"
            return render(request,'base.html',{'posts':[s]},)

def archive(request):
    posts=Enter.objects.all()
    return render(request,'base.html',{'posts':posts})

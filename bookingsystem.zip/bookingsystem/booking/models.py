from django.db import models

# Create your models here.
class Enter(models.Model):
    fname=models.CharField(max_length=50)
    lname=models.CharField(max_length=50)
    age=models.CharField(max_length=50)
    name=models.CharField(max_length=50)



    def __str__(self):
        a="hotel:-" +self.fname+"\nfacilities:-"+self.lname+"\nage:-"+self.age+"\nname:-"+self.name
        return a

    class Meta:
        ordering = ['fname',]

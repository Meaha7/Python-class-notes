from django.contrib import admin

# Register your models here.
from booking import models
admin.site.register(models.Enter)


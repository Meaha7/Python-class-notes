from django.shortcuts import render

# Create your views here.
from django.http import HttpRequest, HttpResponse, HttpResponseRedirect
from django.template import loader
from blog.models import detail,detailsPostForm

def archive(request):
     posts = detail.objects.all()
     t = loader.get_template("archive.html")
     c = dict({'posts': posts,'form': detailsPostForm()})
     return render(request,'archive.html',c)


def create_blogpost(request):
     if request.method == 'POST':
          form = detailsPostForm(request.POST)
          if form.is_valid():
               form.save()
     return HttpResponseRedirect('/blog/view')


from django.contrib import admin

# Register your models here.
from blog import models
class detailsAdmin(admin.ModelAdmin):
     list_display = ('firstName', 'LastName','Address')
admin.site.register(models.detail, detailsAdmin)
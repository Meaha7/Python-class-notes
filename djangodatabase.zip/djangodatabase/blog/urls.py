from django.conf.urls import url
import blog.views
urlpatterns = [url('view/', blog.views.archive),
               url('create/', blog.views.create_blogpost),
               ]

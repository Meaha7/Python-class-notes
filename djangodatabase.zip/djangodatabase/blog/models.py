from django.db import models
from django import forms

# Create your models here.
class detail(models.Model):
     firstName= models.CharField(max_length=150)
     LastName = models.TextField()
     Address = models.TextField()
 

class detailsPostForm(forms.ModelForm):
     class Meta:
        model = detail
        exclude = ()

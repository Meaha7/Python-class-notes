from django import forms

from . models import Restaurant
from . models import Dish
from . models import Review

class RestaurantForm(forms.ModelForm):
        class Meta:
              model = Restaurant
              fields = ['name', 'street']


class DishForm(forms.ModelForm):
        class Meta:
              model = Dish
              exclude = ['user', 'date', 'restaurant',]


from django.contrib import admin

# Register your models here.

from . models import Restaurant
from . models import Dish
from . models import Review

admin.site.register(Restaurant)
admin.site.register(Dish)
admin.site.register(Review)

# Register your models here.
